#!/usr/bin/env bash
set -euo pipefail
SVM_PACKAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SVM_TARGET="$HOME/sites/svm-rakennus"
if [ -e "$SVM_TARGET" ] && [ ! -d "$SVM_TARGET" ]; then echo 'Target is not a directory'; exit 1; fi
if [ -d "$SVM_TARGET" ] && [ -n "$(find "$SVM_TARGET" -mindepth 1 -maxdepth 1 -print -quit)" ]; then
 echo 'Target is not empty; stopped to preserve existing work.'; exit 1
fi
mkdir -p "$SVM_TARGET"
cp -a "$SVM_PACKAGE/project/." "$SVM_TARGET/"
cp "$SVM_PACKAGE/Contrast-selected.html" "$SVM_TARGET/docs/Contrast-selected.html"
printf 'Source copied to: %s\n' "$SVM_TARGET"
